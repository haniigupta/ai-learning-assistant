import mongoose from "mongoose";
// const connectDB = async () =>{
const connectDB = async () =>{
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URL);
        console.log(`Mongodb connected: ${conn.connection.host} `);
    } catch (error){
        console.error(`Error connecting to Mongodb : ${error.message}`);
        process.exit(1);
    }
};
export default connectDB;
