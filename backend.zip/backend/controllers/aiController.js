import Document from '../models/Document.js';
import Flashcard from '../models/Flashcard.js';
import Quiz from '../models/Quiz.js';
import ChatHistory from '../models/ChatHistory.js';
import * as geminiService from '../utils/geminiService.js';
import aiService from '../services/ai/aiService.js';
import { findRelevantChunksByEmbedding } from '../utils/vectorSearch.js';

// @desc Generate flashcards for a document
// @route POST /api/ai/generate-flashcards
// @access Private
export const generateFlashcards = async (req, res, next) => {
    try {
        const { documentId, count = 10 } = req.body;

        if (!documentId) {
            return res.status(400).json({
                success: false,
                message: "documentId is required",
                statusCode: 400
            });
        }
        const document = await Document.findOne({
            _id: documentId,
            userId: req.user._id,
            status: 'ready'
        });
        if (!document) {
            return res.status(404).json({
                success: false,
                message: "Document not found or not ready for processing",
                statusCode: 404
            });
        }

        // generate flashcard using gemini
        const cards = await aiService.generateFlashcards(
            document.extractedText,
            parseInt(count)
        );
        // add flashcard count to document
        const existingFlashcardCount =
    await Flashcard.countDocuments({
        userId: req.user._id,
        documentId: document._id
    });

        // save flashcards to db
        const flashcardSet = await Flashcard.create({

            documentId: document._id,
            userId: req.user._id,
            cards: cards.map(card => ({
                question: card.question,
                answer: card.answer,
                difficulty: card.difficulty,
                reviewCount: 0,
                isStarred: false
            }))


        });


        res.status(200).json({
            success: true,
            data: flashcardSet,
            message: 'Flashcards generated successfully'
        });
    } catch (error) {
        next(error);
    }
};

// @desc Generate quiz for a document
// @route POST /api/ai/generate-quiz
// @access Private
export const generateQuiz = async (req, res, next) => {
    try {
        const { documentId, numQuestions = 5, title } = req.body;
        if (!documentId) {
            return res.status(400).json({
                success: false,
                error: "documentId is required",
                statusCode: 400
            });
        }

        const document = await Document.findOne({
            _id: documentId,
            userId: req.user._id,
            status: 'ready'
        });
        if (!document) {
            return res.status(404).json({
                success: false,
                error: "Document not found or not ready for processing",
                statusCode: 404
            });
        }
        // generate quiz using gemini
        console.log(">>> generateQuiz controller called");
        const quizQuestions = await aiService.generateQuiz(
            document.extractedText,
            parseInt(numQuestions)
        );
       

        //adding quiz count
        const existingQuizCount =
    await Quiz.countDocuments({
        userId: req.user._id,
        documentId: document._id
    });

        // save quiz to db
        const quiz = await Quiz.create({
            documentId: document._id,
            userId: req.user._id,
            title: title ||`${document.title} - Quiz ${existingQuizCount + 1}`,
            questions: quizQuestions,
            totalQuestions: quizQuestions.length,
            userAnswers: [],
            score: 0
        });
        res.status(200).json({
            success: true,
            data: quiz,
            message: 'Quiz generated successfully'
        });
    } catch (error) {
        next(error);
    }
};

// @desc Generate summary for a document
// @route POST /api/ai/generate-summary
// @access Private
export const generateSummary = async (req, res, next) => {
    try {
        const { documentId } = req.body;
        if (!documentId) {
            return res.status(400).json({
                success: false,
                error: "documentId is required",
                statusCode: 400
            });
        }
        const document = await Document.findOne({
            _id: documentId,
            userId: req.user._id,
            status: 'ready'
        });
        if (!document) {
            return res.status(404).json({
                success: false,
                error: "Document not found or not ready for processing",
                statusCode: 404
            });
        }
        // generate summary using gemini
        const summary = await aiService.generateSummary(document.extractedText);

        res.status(200).json({
            success: true,
            data: {
                documentId: document._id,
                title: document.title,
                summary
            },
            message: 'Summary generated successfully'
        });
    } catch (error) {
        next(error);
    }

};

// @desc Chat with the assistant about a document
// @route POST /api/ai/chat
// @access Private
export const chat = async (req, res, next) => {
    try {
        const { documentId, question } = req.body;
        if (!documentId || !question) {
            return res.status(400).json({
                success: false,
                error: "documentId and question are required",
                statusCode: 400
            });
        }
        const document = await Document.findOne({
            _id: documentId,
            userId: req.user._id,
            status: 'ready'
        });
        if (!document) {
            return res.status(404).json({
                success: false,
                error: "Document not found or not ready for processing",
                statusCode: 404
            });
        }
        // find relevant chunks
        const relevantChunks = await findRelevantChunksByEmbedding(document.chunks, question, 5);
        console.log(
            "Retrieved Chunks:",
            relevantChunks.map(chunk => ({
                index: chunk.chunkIndex,
                score: chunk.score
            }))
        );
        const sources = relevantChunks.map(chunk => ({
    chunkIndex: chunk.chunkIndex,
    pageNumber: chunk.pageNumber,
    preview:
        chunk.content.length > 80
            ? chunk.content.substring(0, 80) + "..."
            : chunk.content
}));
        // get or create chat histor
        let chatHistory = await ChatHistory.findOne({
            documentId: document._id,
            userId: req.user._id
        });

        if (!chatHistory) {
            chatHistory = await ChatHistory.create({
                documentId: document._id,
                userId: req.user._id,
                messages: []
            });
        }

        // generate response using gemini
        const response = await geminiService.chatWithContext(question, relevantChunks, chatHistory.messages);

        // save convo
        chatHistory.messages.push(
            {
                role: 'user',
                content: question,
                timestamp: new Date(),
                relevantChunks: [],
            },
            {
                role: 'assistant',
                content: response,
                timestamp: new Date(),
                relevantChunks: [],
            }
        );
        await chatHistory.save();

        res.status(200).json({
    success: true,
    data: {
        question,
        response,
        sources,
        chatHistoryId: chatHistory._id
    },
    message: 'Chat response generated successfully'
});

    } catch (error) {
        next(error);
    }

};

// @desc Explain a concept from the document
// @route POST /api/ai/explain-concept
// @access Private
export const explainConcept = async (req, res, next) => {
    try {
        const { documentId, concept } = req.body;
        if (!documentId || !concept) {
            return res.status(400).json({
                success: false,
                error: "documentId and concept are required",
                statusCode: 400
            });
        }
        const document = await Document.findOne({
            _id: documentId,
            userId: req.user._id,
            status: 'ready'
        });
        if (!document) {
            return res.status(404).json({
                success: false,
                error: "Document not found or not ready for processing",
                statusCode: 404
            });
        }

        //find relevant chunks for concept
        const relevantChunks = await findRelevantChunksByEmbedding(document.chunks, concept, 3);
        const context = relevantChunks.map(c => c.content).join('\n\n');

        // generate explanation using gemini
        const explanation = await geminiService.explainConcept(concept, context);

        res.status(200).json({
            success: true,
            data: {
                concept,
                explanation,
                relevantChunks: relevantChunks.map(c => c.chunkIndex)
            },
            message: 'Concept explanation generated successfully'
        });
    } catch (error) {
        next(error);
    }
};

// @desc Get chat history for a document
// @route GET /api/ai/chat-history/:documentId
// @access Private
export const getChatHistory = async (req, res, next) => {
    try {
        const { documentId } = req.params;
        if (!documentId) {
            return res.status(400).json({
                success: false,
                error: "documentId is required",
                statusCode: 400
            });
        }

        const chatHistory = await ChatHistory.findOne({
            documentId,
            userId: req.user._id
        }).select('messages');

        if (!chatHistory) {
            return res.status(404).json({
                success: false,
                data: [],
                message: "Chat history not found for this document",
                statusCode: 404
            });
        }
        res.status(200).json({
            success: true,
            data: chatHistory.messages,
            message: 'Chat history retrieved successfully'
        });
    } catch (error) {
        next(error);
    }


};